
//https://medium.com/@jeffandersen/building-a-node-js-rest-api-with-express-46b0901f29b6

var express = require('express');

var bodyParser = require('body-parser');

//var app = express();

//express.use(bodyParser.json({ type: 'application/json' }));

var router = express.Router();


var db = require("../connection");

router.get('/recipes', db.getAllRecipes);
router.get('/recipes/:id', db.getRecipeByID);
router.get('/recipes/users/:owner_id', db.getRecipeByUser);
router.post('/recipes/', db.postRecipe);
//app.use('/api', router);

module.exports = router;


