const db =  {
	connectionString: "postgres://fyeznwonhtmkgq:bdf707c421a12f82fbf92c847662f9135d02a0a2bb283aaa531be9760954b3fb@ec2-50-16-196-57.compute-1.amazonaws.com:5432/db5vjg2n7ir74t",
	ssl:true,
	contentType: 'application/json'
};


const pgp = require('pg-promise')();
const connect = pgp(db);

module.exports = {
	getAllRecipes: getAllRecipes,
	getRecipeByID: getRecipeByID,
	getRecipeByUser: getRecipeByUser,
	postRecipe: postRecipe
};

function getAllRecipes(req, res, next){
	connect.any('select * from recipes')
    .then(function (data) {
      res.status(200)
        .json({
          data: data,
        });
    })
    .catch(function (err) {
      return next(err);
    });
}

function getRecipeByID(req, res, next){

	connect.any(`SELECT * from recipes where id = ${req.params.id};`, [true])
    .then(function (data) {
      res.status(200)
        .json({
          data: data,
        });
    })
    .catch(function (err) {
      return next(err);
    });
}

//fix rest of these tomorrow
function getRecipeByUser(req, res, next){
	connect.any(`SELECT * from recipes where owner_id = ${req.params.owner_id};`, [true])
    .then(function (data) {
      res.status(200)
        .json({
          data: data,
        });
    })
    .catch(function (err) {
      return next(err);
    });
}

function postRecipe(req, res, next){
  console.log(req.body);
	connect.none('INSERT INTO recipes(id, owner_id, name, category, public, steps)'+`values(${req.body.id}, ${req.body.owner_id}, ${req.body.name}, ${req.body.category}, ${req.body.public}, ${req.body.steps})`, [true])
	.then(function () {
      res.status(200)
        .json({
          status: 'success',
          message: 'Inserted recipe'
        });
    })
    .catch(function (err) {
      return next(err);
    });
}


